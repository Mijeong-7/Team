import numpy as np 
import pandas as pd
import json

meta = pd.read_csv('data/movies_metadata.csv')
meta.head()

meta = meta[['id', 'original_title', 'original_language', 'genres']]
meta = meta.rename(columns={'id':'movieId'})
meta = meta[meta['original_language'] == 'en']
meta.head()

ratings = pd.read_csv('data/ratings_small.csv')
ratings = ratings[['userId', 'movieId', 'rating']]
ratings.head()

ratings.describe()

meta.movieId = pd.to_numeric(meta.movieId, errors='coerce')
ratings.movieId = pd.to_numeric(ratings.movieId, errors='coerce')

def parse_genres(genres_str):
    genres = json.loads(genres_str.replace('\'', '"'))
    
    genres_list = []
    for g in genres:
        genres_list.append(g['name'])

    return genres_list

meta['genres'] = meta['genres'].apply(parse_genres)

meta.head()

data = pd.merge(ratings, meta, on='movieId', how='inner')
data.head()

combined = pd.merge(meta, ratings)
combined.head()

matrix = data.pivot_table(index='userId', columns='original_title', values='rating')
matrix.head(20)


GENRE_WEIGHT = 0.1
def pearsonR(s1, s2):
    s1_c = s1 - s1.mean()
    s2_c = s2 - s2.mean()
    return np.sum(s1_c * s2_c) / np.sqrt(np.sum(s1_c ** 2) * np.sum(s2_c ** 2))

def recommend(input_movie, matrix, n, similar_genre=True):
    input_genres = meta[meta['original_title'] == input_movie]['genres'].iloc(0)[0]

    result = []
    for title in matrix.columns:
        if title == input_movie:
            continue

        # rating comparison
        cor = pearsonR(matrix[input_movie], matrix[title])
        
        # genre comparison
        if similar_genre and len(input_genres) > 0:
            temp_genres = meta[meta['original_title'] == title]['genres'].iloc(0)[0]

            same_count = np.sum(np.isin(input_genres, temp_genres))
            cor += (GENRE_WEIGHT * same_count)
        
        if np.isnan(cor):
            continue
        else:
            result.append((title, '{:.2f}'.format(cor), temp_genres))
            
    result.sort(key=lambda r: r[1], reverse=True)
    return result[:n]



recommend_result = recommend('The Dark Knight', matrix, 10, similar_genre=True)
ab = pd.DataFrame(recommend_result, columns = ['Title', 'Correlation', 'Genre'])
ab = pd.DataFrame(ab) 
ab.head(10)



#데이터 사람들이 준 별점의 분포, 그 사람들이 평과를 일관되게 하는지 호불호가 강한지, 평을 몇번 하였는지를 그래프로 도출합니다. 
target_col = ['original_title', 'userId', 'rating']
counted = combined[target_col].groupby('userId').agg({'rating' : [np.size, np.mean, np.std]})
popular = counted['rating']['size'] >= 10

popular_movies = counted[popular]

abc = pd.DataFrame(ab, columns = ['Correlation']) 
combined_result = popular_movies.join(abc)
combined_result.sort_values(by = ['Correlation'], ascending = False).head()


#그래프 3종류 한번에 보기
combined_result.hist(bins=20)



# 사람들이 준 별점의 분포거의 점수가 높은 결과값을 볼수 있다.
# 0 부터 5까지 이므로 중간값은 2.5 이지만, 평균은 5에 편향되어있다.
combined_result.hist(('rating', 'mean'))



# 별점을 주는 사람의 표준편차 분포
# 낮을수록 일관된 평가를 하고, 높을수록 호불호 표현이 명확함을 의미 
combined_result.hist(('rating', 'std'))


# 사람들이 영화 평을 몇 번 했는지를 나타내는 분포
combined_result.hist(('rating', 'size'))